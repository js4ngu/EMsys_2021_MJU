#ifndef _BMPVIEWER_H_
#define _BMPVIEWER_H_

#endif
